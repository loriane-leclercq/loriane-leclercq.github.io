#include <stdio.h>



int main(){


  /* array games */
  
  int arr[]={10,11,12,13,14,15}; // try it with an array of shorts, longs,...
  
  for(int i=0;i<6;i++){
    printf("in memory address %p, there is %d\n",arr+i,arr[i]);
  } // because arr+i is equivalent to &arr[i] (or *(arr+i) is equivalent to arr[i]) 
  
  
  for(int i=0;i<6;i++){
    printf("arr[%d] is %d and %d[arr] is %d\n",i,arr[i],i,i[arr]);
  } // because arr[i] is computed as *(arr+i)=*(i+arr) that corresponds to i[arr]
  
  
  /* multi dimentional array */
  
  int matrix[3][3]={
    {0,1,2},
    {3,4,5},
    {6,7,8}
  };
  int (*p)[3][3]=&matrix;
  
  
  void print_matrix(int (*matrix)[3][3]){
    printf("[ \n");
    for(int i=0;i<sizeof(*matrix)/sizeof((*matrix)[0]);i++){
      printf("[ ");
      for(int j=0;j<sizeof((*matrix)[0])/sizeof(int);j++){
	printf("%d",(*matrix)[i][j]);
	if(j<sizeof((*matrix)[0])/sizeof(int)-1)
	  printf(", ");
      }printf(" ]");
      if(i<sizeof(*matrix)/sizeof((*matrix)[0])-1)
	printf(",");
      printf("\n");
    }printf(" ]\n");
  }
  
  print_matrix(p);
  
  int a[3][3];
  printf("Enter elements for a 3X3 matrix\n");
  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      printf("Enter a%d%d: ",i+1,j+1);
      scanf("%d",&a[i][j]);
    }
  }
  
  p=&a;
  
  print_matrix(p);
  
  return 0;
}
