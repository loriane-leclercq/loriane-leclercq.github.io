#include <stdio.h>
#include <stdlib.h>
#include <string.h>



typedef struct person{
  char name[20];
  int age;
  char eye_color[20];
}person;

typedef struct element{
  person data;
  struct element *next;
}element;

/* prints a list of persons using their name */
int printList(element* list){
  element *current=list;
  printf("[ ");
  while(current!=NULL){
    printf("%s age %d",current->data.name, current->data.age);
    if(current->next!=NULL)
      printf(", ");
    current=current->next;
  }
  printf(" ]\n");
  
  return 0;
  
}


/* insertFirst instert a new person p at the beginning of the list */
int insertFirst(element** list, person p){
  element *new_list=(element*)malloc(sizeof(element));
  new_list->data=p;
  new_list->next=*list;
  
  *list=new_list;
  
  return 0;
}

/* tests if two persons are equal, this test can be modified if we want to have
   consider that persons with the same eye_color are equal,  or with the same 
   Social Security Number for example */
int equalPerson(person p1, person p2){
  return (!strcmp(p1.name,p2.name));
}

/* returns 1 and remove the person p if it is in the list, returns 0 otherwise */
int removeData(element** list, person p){
  int found=0;
  element * current=*list;
  if(current!=NULL && equalPerson(current->data,p)){
    *list=current->next;
    found=1;
  } 
  while(current!=NULL){
    if(current->next!=NULL){
      if(equalPerson(current->next->data,p)){
	current->next=current->next->next;
	found=1;
      }
    }current=current->next;
  }
  return found;
}





int main(){
  

  element *head = NULL;
  person p1;
  strcpy(p1.name,"Jane");
  p1.age=25;
  strcpy(p1.eye_color,"brown");
  person p2={.name="Ash",.age=20,.eye_color="green"};
  person p3={.name="John",.age=10,.eye_color="blue"};
  person p0={.name="Max",.age=30,.eye_color="brown"};

  insertFirst(&head,p1);
  printList(head); // [ Jane ]
  insertFirst(&head,p2);
  printList(head); // [ Ash, Jane ]
  insertFirst(&head,p0);
  printList(head); // [ Max, Ash, Jane ]
  insertFirst(&head,p3);
  printList(head); // [ John, Max, Ash, Jane ]
  removeData(&head,p0);
  printList(head); // [ John, Ash, Jane ]

  return 0;
}
