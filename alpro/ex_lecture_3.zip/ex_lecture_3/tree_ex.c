#include <stdio.h>
#include <stdlib.h>
#include <string.h>



typedef struct person{
  int nbr;
  char name[20];
  int age;
  char eye_color[20];
}person;

typedef struct node{
  person data;
  struct node *left, *right;
}node;


/* prints the binary tree starting from the most left */
int printSubTree(node* tree){
  if(tree!=NULL){
    printSubTree(tree->left);
    printf("%d: %s ",tree->data.nbr,tree->data.name);
    printSubTree(tree->right);
  }
  //perror("TODO: Students, this is your work !\n");
  return 0;
}

int printTree(node* tree){
  printf("Tree : ");
  printSubTree(tree);
  printf("\n");
}

/* tests if the number of a person p1 is bigger than a person p2 */
int bigger_pers(person p1, person p2){
  return p1.nbr > p2.nbr;
}

/* tests if two persons have the same number */
int equal_pers(person p1, person p2){
  return p1.nbr = p2.nbr;
}

/* add a node to the right place in the binary tree, according to its number */
int addNode(node** root, person p){
  node *new_node=(node*)malloc(sizeof(node));

  node *new_root=*root;
  node *tmp_node;

  new_node->data=p;
  new_node->left=NULL;
  new_node->right=NULL;
  
  if(*root==NULL)
    *root=new_node;
  else{
    while(new_root!=NULL){
      tmp_node=new_root;
      if(bigger_pers(p,tmp_node->data)){
	new_root=new_root->right;
	if(new_root==NULL)
	  tmp_node->right=new_node;
      }else{
	new_root=new_root->left;
	if(new_root==NULL)
	  tmp_node->left=new_node;
      }
    }
  }
  
  return 0;
}


/* recursively add a node to the right place in the binary tree, according to 
   its number */
node* recAddNode(node* root, person p){
  if(root==NULL){
    node *new_node=(node*)malloc(sizeof(node));
    new_node->data=p;
    new_node->left=NULL;
    new_node->right=NULL;
    return new_node;
  }
  if(bigger_pers(p,root->data))
    root->right=recAddNode(root->right,p);
  else
    root->left=recAddNode(root->left,p);
  return root;
}



node* minValue(node* root){
  node* current=root;
  
  /* go to the leftmost leaf */
  while(current!=NULL && current->left!=NULL)
    current=current->left;
  return current;
}


person search_nbr(node* root, int nbr){
  if(root==NULL) perror("No person with this number");
  if(root->data.nbr>nbr){
    return search_nbr(root->left,nbr);
  }
  if(root->data.nbr<nbr){
    return search_nbr(root->right,nbr);
  }
  return root->data;
}








node* removeNode(node* root,person p){
  if(root==NULL)
    return root;
  if(equal_pers(p,root->data)){
    node* tmp;
    if(root->left==NULL){
      tmp=root->right;
      free(root);
      return tmp;
    }
    else if(root->right==NULL){
      tmp=root->left;
      free(root);
      return tmp;
    }
    tmp=minValue(root->right);
    root->data=tmp->data;
    root->right=removeNode(root->right,tmp->data);
  }else if(bigger_pers(p,root->data))
    root->right=removeNode(root->right,p);
  else
    root->left=removeNode(root->left,p);
  return root;
    
}






int main(){
  

  node *tree = NULL;
  person p1;
  p1.nbr=1;
  strcpy(p1.name,"Jane");
  p1.age=25;
  strcpy(p1.eye_color,"brown");
  person p2={.nbr=3,.name="Ash",.age=20,.eye_color="green"};
  person p3={.nbr=2,.name="John",.age=10,.eye_color="blue"};
  person p5={.nbr=8,.name="A",.age=20,.eye_color="green"};
  person p6={.nbr=5,.name="B",.age=10,.eye_color="blue"};
  person p7={.nbr=7,.name="C",.age=20,.eye_color="green"};
  person p8={.nbr=4,.name="D",.age=10,.eye_color="blue"};

  addNode(&tree,p1);
  printf("%s\n",tree->data.name);
  addNode(&tree,p2);
  printf("%s\n",tree->right->data.name);
  addNode(&tree,p3);
  printf("%s\n",tree->right->left->data.name);
  printTree(tree);
  person p4=search_nbr(tree,2);
  printf("%s\n",p4.name);
  addNode(&tree,p5);
  addNode(&tree,p6);
  addNode(&tree,p7);
  addNode(&tree,p8);
  printTree(tree);
  removeNode(tree,p5);
  printTree(tree);
  
  return 0;
}
