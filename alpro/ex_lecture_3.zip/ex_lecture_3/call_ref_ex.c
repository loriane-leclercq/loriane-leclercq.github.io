#include <stdio.h>

void switch_numbers(int *i1, int *i2, int *i3){
  int j=*i1;
  *i1=*i2;
  *i2=*i3;
  *i3=j;
}

int main(){
  int a=0;
  int b=1;
  int c=2;
  printf("a, b and c are %d, %d and %d\n",a,b,c);
  switch_numbers(&a,&b,&c);
  printf("a, b and c are now %d, %d and %d\n",a,b,c);
}
