#!/usr/bin/python

from Types import *
from Utilities import *
from People import *

import sys
sys.setrecursionlimit(20000)


# first try list:

#pers1=Person("Jane","Doe",1)
#pers2=Person("John","Doe",2)
#pers3=Person("Ash","Ley",3)

#pers1.printPerson()
#pers2.printPerson()
#pers3.printPerson()

#list_pers=PersonList(pers1)
#list_pers.printList()
#print("add John: ")
#list_pers=addList(list_pers,pers2)
#list_pers.printList()
#print("add Ash: ")
#list_pers=addList(list_pers,pers3)

#list_pers.printList()   

small_test=False # to go for small tests or big tests


if small_test:

    # with random files:

    names,fst_names=initArrayNamesFstname()
    generateFile(names,fst_names,50)

    #for python list:
    print("using python list")
    p_list=readFilePythonList()
    printPythonList(p_list)
    pers0=p_list[20]
    print(searchPythonList(p_list,pers0))
    p_list=removePythonList(p_list,pers0) 
    #    foud=searchPythonList(p_list,pers0) # throw error because remoned
    #    print(found)
    printPythonList(p_list)


    #for list:
    print("\n\n\n")
    print("with lists")
    rand_list=readFileList()    
    rand_list.printList()
    pers1=rand_list.next_p.next_p.next_p.next_p.next_p.data
    print(searchList(rand_list,pers1,0))
    rand_list=removeList(rand_list,pers1)
    print(searchList(rand_list,pers1,0))
    rand_list.printList()
    
    
    # for tree:
    print("\n\n\n")
    print("Trees now\n")
    rand_tree=readFileTree()
    rand_tree.printTree()
    pers2=rand_tree.right.left.right.data
    
    print("")
    print("search for")
    found=searchTree(rand_tree,pers2)
    if found:
        found.printPerson()
        rand_tree=removeTree(rand_tree,pers2)
        
    print("")
    print("removed")
    #rand_tree.printTree()
    found=searchTree(rand_tree,pers2)
    if found:
        found.printPerson()
        rand_tree.printTree()



else:

    # compare times:

    from time import time, sleep



    names,fst_names=initArrayNamesFstname()
    generateFile(names,fst_names,10000)

    
    # reading
    start_time1=time()
    p_list=readFilePythonList()
    end_time1=time()


    start_time2=time()
    rand_list=readFileList()
    end_time2=time()

    start_time3=time()
    rand_tree=readFileTree()
    end_time3=time()


    print("Reading with python list:",end_time1-start_time1,"seconds")
    print("Reading with implemented list:",end_time2-start_time2,"seconds")
    print("Reading with binary tree:",end_time3-start_time3,"seconds")

    print("Now sleeping for 5 seconds for you to be able to see results")
    sleep(5)
    

    # printing
    start_time1=time()
    printPythonList(p_list)
    end_time1=time()


    start_time2=time()
    rand_list.printList()
    end_time2=time()

    start_time3=time()
    rand_tree.printTree()
    end_time3=time()
    
    print()
    print("Printing python list:",end_time1-start_time1,"seconds")
    print("Printing implemented list:",end_time2-start_time2,"seconds")
    print("Printing tree:",end_time3-start_time3,"seconds")

    #print("Now sleeping for 5 seconds for you to be able to see results")
    #sleep(5)

    # search    
    to_search=[]
    for i in range(1000):
        n=random.randint(0,10000)
        while p_list[n] in to_search:
            n=random.randint(0,10000)
        to_search.append(p_list[n])
        
    
    start_time1=time()
    for pers in to_search:
        searchPythonList(p_list,pers)
    end_time1=time()


    start_time2=time()
    for pers in to_search:
        searchList(rand_list,pers,0)
    end_time2=time()

    start_time3=time()
    for pers in to_search:
        searchTree(rand_tree,pers)
    end_time3=time()
    
    print()
    print("Searching in python list:",end_time1-start_time1,"seconds")
    print("Searching in implemented list:",end_time2-start_time2,"seconds")
    print("Searching in tree:",end_time3-start_time3,"seconds")

    #print("Now sleeping for 5 seconds for you to be able to see results")
    #sleep(5)



    # remove   
    start_time1=time()
    for pers in to_search:
        removePythonList(p_list,pers)
    end_time1=time()


    start_time2=time()
    for pers in to_search:
        removeList(rand_list,pers)
    end_time2=time()

    start_time3=time()
    for pers in to_search:
        removeTree(rand_tree,pers)
    end_time3=time()
    

    print()
    print("Removing python list:",end_time1-start_time1,"seconds")
    print("Removing implemented list:",end_time2-start_time2,"seconds")
    print("Removing tree:",end_time3-start_time3,"seconds")


