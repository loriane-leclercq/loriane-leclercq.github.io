#!/usr/bin/python

import random
from Types import *


def initArrayNamesFstname():
    f_in=open("Names.txt","r")
    lines=f_in.read().splitlines() #f_in.readlines() store the '\n' char in string
    names=[]
    for line in lines[1:]: # [1:] to suppress the line with the number of names in the file
        names.append(line)
    f_in.close()
    f_in=open("First_names.txt","r")
    lines=f_in.read().splitlines()
    fst_names=[]
    for line in lines[1:]:
        fst_names.append(line)
    f_in.close()

    return names,fst_names


def generatePerson(names,fst_names):
    pers=Person( names[random.randint(0,len(names)-1)],
                 fst_names[random.randint(0,len(fst_names)-1)],
                 random.randint(0,10000000) )
    return pers
    

def generateFile(names,fst_names,size):
    f_out=open("People.txt","w")
    f_out.close()
    f_out=open("People.txt","a")
    for i in range(size): 
        pers=generatePerson(names,fst_names)
        f_out.write(pers.name+" "+pers.fst_name+" "+str(pers.nbr)+"\n")

    
def equalityPerson(p1,p2):
    if p1 and p2:
        return p1 is p2
        # return (p1.name==p2.name and p1.fst_name==p2.fst_name and p1.nbr==p2.nbr)
    return False

def smallerPerson(p1,p2):
    return ( p1.name<p2.name or
             (p1.name==p2.name and (p1.fst_name<p2.fst_name or
                                    p1.fst_name==p2.fst_name and p1.nbr<p2.nbr)))
    
    
