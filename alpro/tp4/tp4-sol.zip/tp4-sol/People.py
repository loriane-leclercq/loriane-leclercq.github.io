#!/usr/bin/python

from Types import *
from Utilities import *


# List of person from python

def printPythonList(python_l):
    for i in range(len(python_l)):
        python_l[i].printPerson()


def addPythonList(python_l,pers):
    current=0
    while ( current<len(python_l) and smallerPerson(python_l[current],pers) ):
        current=current+1
    python_l.insert(current,pers)
    return python_l

def readFilePythonList():
    f_in=open("People.txt","r")
    lines=f_in.read().splitlines() 

    people=[]
    for line in lines:
        words=line.split(" ")
        people=addPythonList(people,Person(words[0],words[1],(int)(words[2])))
    f_in.close()
    return people

def searchPythonList(python_l,pers): #,index
    return python_l.index(pers)

def removePythonList(python_l,pers):
   python_l.remove(pers)
   return python_l


# Linked list

def addList(list_p,pers):
    current=list_p
    if (list_p==None or  smallerPerson(pers,list_p.data)):
        new_pers=PersonList(pers)
        new_pers.next_p=current
        return new_pers

    while (current.next_p and smallerPerson(current.next_p.data,pers)):
        current=current.next_p
            
    new_pers=PersonList(pers)
    new_pers.next_p=current.next_p
    current.next_p=new_pers
    return list_p
    
def readFileList():
    f_in=open("People.txt","r")
    lines=f_in.read().splitlines() 

    people=None
    for line in lines:
        words=line.split(" ")
        people=addList(people,Person(words[0],words[1],(int)(words[2])))
    f_in.close()
    return people


def searchList(list_p,pers,index):
    if not list_p or smallerPerson(pers,list_p.data):
        return -1
    if equalityPerson(pers,list_p.data):
        return index
    return searchList(list_p.next_p,pers,index+1)


def removeList(list_p,pers):
    if not list_p or smallerPerson(pers,list_p.data):
        return list_p
    if equalityPerson(pers,list_p.data):
        return list_p.next_p
    list_p.next_p=removeList(list_p.next_p,pers)
    return list_p
    



#Binary tree

def addTree(tree,pers):
    current=tree
    if not tree:
        new_pers=PersonNode(pers)
        return new_pers

    if smallerPerson(tree.data,pers):
        tree.right=addTree(tree.right,pers)
    if smallerPerson(pers,tree.data):
        tree.left=addTree(tree.left,pers)
    return tree

    
def readFileTree():
    f_in=open("People.txt","r")
    lines=f_in.read().splitlines() 

    people=None
    for line in lines:
        words=line.split(" ")
        people=addTree(people,Person(words[0],words[1],(int)(words[2])))
    f_in.close()
    return people


def searchTree(tree,pers):
    if not tree:
        print("This person is not in the tree")
        return None
    if equalityPerson(pers,tree.data):
        return tree.data
    if smallerPerson(pers,tree.data):
        return searchTree(tree.left,pers)
    if smallerPerson(tree.data,pers):
        return searchTree(tree.right,pers)


def removeTree(tree,pers):
    if not tree: 
        return tree
    if equalityPerson(pers,tree.data):
        if not tree.left:
            return tree.right
        elif not tree.right:
            return tree.left
        tmp=minValue(tree.right)
        tree.data=tmp.data
        tree.right=removeTree(tree.right,tmp.data)
    if smallerPerson(pers,tree.data):
        tree.left=removeTree(tree.left,pers)
    if smallerPerson(tree.data,pers):
        tree.right=removeTree(tree.right,pers)
    return tree
        

def minValue(tree):
    current=tree
    while(current and current.left):
        current=current.left
    return current

    
