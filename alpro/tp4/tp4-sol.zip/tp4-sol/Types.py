#!/usr/bin/python


class Person:
    "a person with a name, a first name and a unique number"
    
    def __init__(self,name,fst_name,nbr):
        self.name=name
        self.fst_name=fst_name
        self.nbr=nbr
        
    def printPerson(self):
        #print("Name: ",self.name, ", First name: ",self.fst_name,", Number: ",self.nbr)
        print(self.name,self.fst_name,self.nbr)


class PersonList:
    "a simply linked list of Person"

    def __init__(self,pers):
        self.next_p=None
        self.data=pers

    def printList(self):
        self.data.printPerson()
        if self.next_p:
            self.next_p.printList()





class PersonNode:
    "a binary tree of Person"

    def __init__(self,pers):
        self.left=None
        self.right=None
        self.data=pers

    def printTree(self):
        if self.data:
            if self.left:
                self.left.printTree()
            self.data.printPerson()
            if self.right:
                self.right.printTree()

    
    
 
