#!/usr/bin/python

from Types import *


import sys
sys.setrecursionlimit(20000)


print("Hello world!")
