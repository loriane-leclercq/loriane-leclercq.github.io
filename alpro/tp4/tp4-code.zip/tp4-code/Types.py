#!/usr/bin/python


class Person:
    "a person with a name, a first name and a unique number"
    
    def __init__(self,name,fst_name,nbr):
        self.name=name
        self.fst_name=fst_name
        self.nbr=nbr
        
    def printPerson(self):
        #print("Name: ",self.name, ", First name: ",self.fst_name,", Number: ",self.nbr)
        print(self.name,self.fst_name,self.nbr)

