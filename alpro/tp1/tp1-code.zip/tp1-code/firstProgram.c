/* 
file first_program.c

compute the n-th first Fibonacci numbers u(n) (such that u(n+1)=u(n)+u(n-1)), 
starting with u(0)=1, u(1)=(1-squareroot(5))/2
*/

#include <stdlib.h> // for the standard library
#include <stdio.h> // for read/write
#include <math.h> // for square root sqrt et power pow


int main(void)
{
  // constants and variables declaration
  const float r = (1-sqrt(5))/2;
  int i,n;
  float last_u, current_u, next_u, p; // for u(n-1), u(n), u(n+1) and r^n

  // initializations
  printf("computation of the n first Fibonacci numbers\n");
  printf("with u0=1, u1=(1-squareroot(5))/2\n");
  printf("n = ?\n");
  scanf("%d",&n);
  last_u=1;
  current_u=r;


  // computation of u(2),...,u(n)
  for (i=2;i<=n;i=i+1)
    {
      next_u=current_u+last_u;
      last_u=current_u;
      current_u=next_u;
      // complete with the printing of the power i-1 of r : pow(r,i)
      // search in the documentation if needed
      printf("u(%d) = %f\n",i,current_u); // use %d to print an integer and %f to print a float
      p=pow(r,i);
      printf("r^%d = %f\n",i,p);
      printf("delta(%d) = %f",i,fabs(current_u-p));
      printf("\n");
    }

  return (EXIT_SUCCESS);
}
