/*
  file big_int.h
  to define the type bigInt
*/

#ifndef BIG_INT_H
#define BIG_INT_H

#include <stdbool.h>

#define DIGITSMAX 20

typedef int intArray[DIGITSMAX];

typedef struct bigInt
{
  bool negative;
  intArray digits;
}bigInt;

#endif
