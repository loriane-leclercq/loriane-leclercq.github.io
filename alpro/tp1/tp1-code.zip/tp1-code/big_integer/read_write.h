/*
  file read_write.h
  to declare the functions of read_write.c
*/

#ifndef READ_WRITE_H
#define READ_WRITE_H

//function printBigInt(n)
//displays a BigInt on the screen
void printBigInt(bigInt);

//function readBigInt
//read a bigInt from the keyboard
bigInt readBigInt();

#endif
