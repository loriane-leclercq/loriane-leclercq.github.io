/*
  file read_write.c
  contains
  - the action printBigInt(n)
  - the function readBigInt
*/

// include header files

#include <stdio.h> //for print and read

#include <string.h> // for strlen
#include <ctype.h> // for toascii
#include <errno.h> // for stderr
#include <stdlib.h> // for exit

#include "big_int.h" // for the type bigInt

#include "read_write.h" /* optional: allows to verify that tyes of parameters 
			   in the prototypes are the same as those in the 
			   corresponding actions/functions 
			*/

//function printBigInt(n)
//print a bigInt on the screen
void printBigInt(bigInt a)
{
  
  
  //variables
  int i,j;
  // begin
  
  // sign
  if (a.negative)
    {
      printf("-");
    }
  // digits
  /* we search for the first non-nul digit (or the unite digit in the case of 
     a nul integer) 
  */
  i=DIGITSMAX-1;
  while ((a.digits[i]==0)&&(i>0))
    {
      i=i-1;
    }
  /*we write the usefull digits*/
  for(j=i;j>=0;j=j-1)
    {
      printf("%d",a.digits[j]);
    }
  printf("\n");
  // end
}



//function readBigInt
//read a bigInt from the keyboard
bigInt readBigInt()
{
  //variables
  char nb[DIGITSMAX+1];
  bigInt a;
  int i,l;
  char c;
  
  // begin
  scanf("%s",nb);
  a.negative = (nb[0]=='-');
  l=strlen(nb);
  if ((a.negative)||(nb[0]=='+'))
    {
      //we shift the character of end of string by one index to the left. 
      for(i=0;i<l;i=i+1)
    	{
	  nb[i]=nb[i+1];
    	}
      l=strlen(nb);
    }
  for (i=0;i<l;i=i+1)
    {
      c=nb[l-1-i];
      if('0'<=c &&  c<='9')
	a.digits[i] =c-'0';
      else
	{
	  fprintf(stderr, "The caracter %c is not a digit\n",c);
	  exit(EXIT_FAILURE);
	}
    }
  // we complete with 0's
  for (i=l;i<DIGITSMAX;i=i+1)
    {
      a.digits[i]=0;
    }
  return a;
  // end
}
