/*
  author : V. Tourre, carried in C by L. Leclercq
  date : 26-09-2017, 02-09-2022
  file name : debug.c
  
  Do not remove any instruction from this program. You must add the necessary 
  elements for the compilation and execution to run correctly
*/

#include <stdlib.h>
#include <stdio.h>


int main(void){

  int nbBug;
  printf("How many bugs do you thing I have ?\n");
  scanf("%d",&nbBug);


  while(nbBug<0){ 
    printf("The number of bugs must be greater or equal to zero\n");
    scanf("%d",&nbBug);
  }

  printf("You said I have ");
  if(nbBug == 0 || nbBug == 1) { 
    printf("%d bug\n",nbBug);
  }else{
    printf("%d bugs\n",nbBug);
  }
  return(EXIT_SUCCESS);
}

