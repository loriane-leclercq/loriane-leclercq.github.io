/*
  file utilities.h
  to declare the functions of utilities.c
*/

#ifndef UTILITIES_H
#define UTILITIES_H

// function that convert an integer n to a bigInt
bigInt convert(int n);

// function that test if two bigInt a and b are equal
int equal(bigInt a,bigInt b);

// function that test if between two bigInt the first is smaller or equal to the second
int leq(bigInt a,bigInt b);

// function that return the number of digits in e
int nb_digits(bigInt e);

#endif
