#include <stdio.h>

#include "big_int.h"
#include "read_write.h"
#include "utilities.h"
#include "operations.h"

int main() {
  bigInt a,b;

  /* to try the read and print functions */
  //while(true){
  //  a=readBigInt();
  //  printBigInt(a);
  //}

  /* to try the convert function */
  // b=convert(1234); 
  // printBigInt(b); 
  
  // b=convert(-123456789); 
  // printBigInt(b);
  
  /* to try the equal, less or equal, addition and subtraction fuctions */
  //a=convert(12345);
  //printBigInt(a);
  //b=convert(-98765);
  //printBigInt(b);
  //printf("a equals b ? %d\n",equal(a,b));
  //printf("a less or equals b ? %d\n",leq(a,b));
  //printf("a+b= ");
  //printBigInt(add(a,b));
  //printf("a-b= ");
  //printBigInt(subtract(a,b));

  /* fibonacci with big integers */
  int n=60;
  printf("fibonacci of %d : ",n);
  printBigInt(fibonacci(n));
  printf("fibonacci(60)-fibonacci(59)=fibonacci(58) ? %d\n",equal(subtract(fibonacci(60),fibonacci(59)),fibonacci(58)));
  printf("fibonacci(60)-fibonacci(59) : ");
  printBigInt(subtract(fibonacci(60),fibonacci(59)));
  printf("fibonacci(58) : ");
  printBigInt(fibonacci(58));

  /* for the multiplication */
  // a=convert(999999999);
  // b=convert(99999999);
  // bigInt m=multiply(a,b);
  // printBigInt(m);

  /* for the division */
  // a=convert(812);
  // b=convert(3);
  // bigInt d=divide(a,b);
  // printBigInt(d);
  
  
  return 0;
}
