/*
  file utilities.c
  contains functions: 
  - convert(n), 
  - equal(a,b) and 
  - leq(a,b)
*/

#include "big_int.h" // for the type bigInt

#include "utilities.h" /* allows to verify that tyes of parameters 
			  in the prototypes are the same as those in the 
			  corresponding actions/functions 
		       */


// function to convert an integer n to a bigInt
bigInt convert(int n){
  bigInt r;
  r.negative=0;
  if(n<0){
    r.negative=1;
    n=-n;
  }
  for(int i=0;i<DIGITSMAX;i++){
    if(n>0){
      r.digits[i]=n%10;
      n/=10;
    }
    else r.digits[i]=0;
  }
  return r;
}


// function to test if two bigInt a and b are equal
int equal(bigInt a,bigInt b){
  if (a.negative!=b.negative)
    return 0;
  for(int i=0;i<DIGITSMAX;i++){
    if (a.digits[i]!=b.digits[i])
      return 0;
  }
  return 1;
}

// function to test if between two bigInt the absolute value of first is smaller or equal to that of the second
int leq(bigInt a,bigInt b){
  for(int i=DIGITSMAX;i>0;i--){
    if(a.digits[i-1]>b.digits[i-1])
      return 0;
    else if(a.digits[i-1]<b.digits[i-1])
      return 1;    
  }
  return 1;
}

/*
int leq(bigInt a,bigInt b){
  if (b.negative && !a.negative)
    return 0;
  if (a.negative && !b.negative)
    return 1;
  for(int i=DIGITSMAX;i>0;i--){
    if (!a.negative && !b.negative && a.digits[i-1]>b.digits[i-1]
	|| a.negative && b.negative && a.digits[i-1]<b.digits[i-1])
      return 0;
    
  }
  return 1;
}
*/



int nb_digits(bigInt e){
  int n=0,i=DIGITSMAX-1;
    while(e.digits[i]==0 && i>=0){i--;n++;}
    return (DIGITSMAX-n);
}
