/*
  file operations.h
  to declare the functions of operations.c
*/

#ifndef OPERATIONS_H
#define OPERATIONS_H

// function to add two bigInts of the same sign
bigInt add_abs(bigInt,bigInt);

// function to substract two bigInts of the same sign and with the first bigger or equal to the second
bigInt subtract_abs(bigInt,bigInt);

// function to add two bigInts of any sign
bigInt add(bigInt,bigInt);

// function to subtract two bigInts of any sign
bigInt subtract(bigInt,bigInt);

//function to multiply two bigInts
bigInt multiply(bigInt,bigInt);

// function to compute the n-th fibonacci number
bigInt fibonacci(int);

// function to divide two bigInts
bigInt divide(bigInt a,bigInt b);

// function that compute b to the power of e using the multiply function
bigInt power(bigInt a,bigInt e);


#endif
