/*
  file operations.c
  contains functions:
  - add_abs
  - subtract_abs
  - add
  - subtract
 */

#include <stdio.h>

#include "big_int.h"
#include "utilities.h"
#include "operations.h"

// function to add bigInts a and b of the same sign
bigInt add_abs(bigInt a,bigInt b){
  int r=0;
  for(int i=0;i<DIGITSMAX;i++){
    a.digits[i]+=b.digits[i]+r;
    r=0;
    if(a.digits[i]>9){
      r=1;
      a.digits[i]%=10;
    }
  }
  return a;
}

// function to substract bigInts a and b of the same sign and with |a|<=|b|
bigInt subtract_abs(bigInt a,bigInt b){
  int r=0;
  for(int i=0;i<DIGITSMAX;i++){
    a.digits[i]=a.digits[i]-b.digits[i]-r;
    r=0;
    if(a.digits[i]<0){
      r=1;
      a.digits[i]+=10;
    }
  }
  a.negative=0;
  return a;
}

// function to add bigInts a and b
bigInt add(bigInt a,bigInt b){
  if (a.negative==b.negative)
    return add_abs(a,b);
  bigInt r;
  if (leq(a,b)){
    r=subtract_abs(b,a);
    r.negative=b.negative;
  }
  else{
    r=subtract_abs(a,b);
    r.negative=a.negative;
  }
  return r;
}


// function to subtract bigInts a and b
bigInt subtract(bigInt a,bigInt b){
  if(equal(a,b))
    return convert(0);
  bigInt r;
  if (a.negative!=b.negative){
    r=add_abs(a,b);
    r.negative=a.negative;
  }else if (leq(a,b)){
    r=subtract_abs(b,a);
    r.negative=b.negative;
  }else{
    r=subtract_abs(a,b);
    r.negative=a.negative;
  }return r;
}


/*
bigInt subtract(bigInt a,bigInt b){ // cheat version of subtraction
  b.negative=!b.negative;
  return add(a,b);
}
*/


// function to compute the n-th fibonacci number
bigInt fibonacci(int n){
  if (n<2)
    return convert(n);
  bigInt snd_last=convert(0);
  bigInt last=convert(1);
  bigInt current=convert(1);
  for(int i=2;i<=n;i++){
    current=add(last,snd_last); // compute fibonacci(n-1)+fibonacci(n-2)
    snd_last=last;
    last=current;
  }
  return current;
}



//function to multiply two bigInts
bigInt multiply(bigInt a,bigInt b){
  bigInt res=convert(0);
  res.negative=(a.negative!=b.negative);
  bigInt lnth=convert(0);
  int retain=0,val=0,last_ret=0;
  if(nb_digits(a)+nb_digits(b)>=DIGITSMAX){
    printf("The result will be too big even for a bigInt\n");
    return res;
  }else{
    for(int i=0;i<=nb_digits(a);i++){
      lnth=convert(0);
      retain=0;
      for(int j=0;j<=nb_digits(b);j++){
	val= a.digits[i]*b.digits[j]+retain+lnth.digits[i+j];
	retain=val/10;
	lnth.digits[i+j]=val%10;
	last_ret++;
      }
      if(retain!=0){lnth.digits[last_ret]=retain;}
      res=add(res,lnth);
    }
    res.negative=!(a.negative==b.negative);
    return res;
  }
}


// function that divides two bigInts
bigInt divide(bigInt a,bigInt b){
  bigInt res=convert(0);
  if(a.negative || b.negative){
    printf("negative dividend and/or divisor\n");
    return res;
  }
  // trivial
  if(equal(b,convert(0))){
    printf("divisor equal 0\n");	
    return res;
  }
  // trivial
  if(equal(a,b)){
    printf("divisor and dividend equals\n");
    return convert(1);
  }
  // We can divide only if the divisor is smaller than dividend 
  // Equality is done above
  if(leq(a,b)){
    printf("dividend is bigger than divisor\n");
    return convert(0);
  }
  
  // General case
  bigInt r=a,d=convert(10),u=convert(1),n=convert(0),c=convert(0);
  while(leq(b,r)){
    n=convert(-1);
    c=convert(-1);
    
    while(leq(multiply(b,power(d,add(n,u))),r))
      n=add(n,u);
    
    while(leq(multiply(multiply(b,power(d,n)),add(c,u)),r))
      c=add(c,u);
    
    res=add(res,multiply(c,power(d,n)));
    r=subtract(r,multiply(b,multiply(c,power(d,n))));
  }
  return res;
}

// function that compute b to the power of e using the multiply function
bigInt power(bigInt b,bigInt e){
  bigInt r=convert(1);
  bigInt c=convert(1);
  while(leq(c,e)){
    r=multiply(r,b);
    c=add(c,convert(1));
  }return r;
}
