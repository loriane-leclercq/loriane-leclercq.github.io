#include "utilities.h"

void print_match(match m){
  printf("(%d %d) ",m.color,m.size);
}

/* print matches on terminal */
void print_matches(m_array a){
  for(int i=0;i<a.length;i++){
    print_match(a.matches[i]);
  }printf("\n");
}

/* initialize an array of matches of length l*/
m_array init_matches(int l){
  m_array r;
  r.matches=malloc(sizeof(match)*l);
  r.length=l;
  return r;
}


/* read a m_array of matches from the file from path */
m_array read_matches(const char *path){

  FILE *input;
  input=fopen(path,"r");
  if(input==NULL){
    fprintf(stderr,"\n ERROR : Impossible to read the file %s\n", path);
    exit(1);
  }
  int max_length_line=1024;
  char *line=(char*)malloc(max_length_line);
  char *buff;
  
  /* get content line by line */
  line=fgets(line,max_length_line,input);
  int size=atoi(line);
  m_array m=init_matches(size);
  int i=0;
  line=fgets(line,max_length_line,input);
  while(!feof(input) && i<size){
    buff=strtok(line," "); // to get the first word of the line
    m.matches[i].color=atoi(buff);
    buff=strtok(NULL," "); // to get the next word of the line
    m.matches[i].size=atoi(buff);
    
    line=fgets(line,max_length_line,input);
    i++;
  }
  fclose(input);
  return m;
  
}


/* write the m_array of matches m in the file from path */
void write_matches(m_array m,const char* path){

  FILE *output;
  output=fopen(path,"w");
  if(output==NULL){
    fprintf(stderr,"\n ERROR : Impossible to open the file %s\n", path);
    exit(1);
  }

  fprintf(output,"%d\n",m.length);
  for(int i=0;i<m.length;i++){
    fprintf(output,"%d %d\n",m.matches[i].color,m.matches[i].size);
  }
  
  fclose(output);

}


/* compare two matches */
int leq(match m1,match m2){
  //return m1.size<=m2.size;
  //return (m1.size<m2.size || (m1.size==m2.size && m1.color<=m2.color)); // sorted by size and then color
  return (m1.color<m2.color || (m1.color==m2.color && m1.size<=m2.size)); // sorted by color and then size
}


/* construct a m_array of n random matches */
m_array random_matches(int n){
  m_array m=init_matches(n);
  srand(time(NULL));
  for(int i=0;i<n;i++){
    m.matches[i].color=1+rand()%6;
    m.matches[i].size=1+rand()%20;
  }
  return m;
}
