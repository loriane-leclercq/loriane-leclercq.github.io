#include <stdio.h>
#include "matches.h"
#include "sorts.h"
#include "display.h"
#include "utilities.h"


/* function to insert the match from position j to position i and shift all the 
   following ones */
void insert(m_array *m,int i,int j){
  if(j<i){ 
    match tmp = m->matches[i]; 
    for(int k=i;k>j;k--){ 
      m->matches[k]=m->matches[k-1]; 
    }m->matches[j]=tmp; 
  } 
}

/* insertion sort function */
void insert_sort(m_array *m){
  for(int i=1;i<m->length;i++){ 
    int j=0; 
    while((j<i) && leq(m->matches[j],m->matches[i])) j++;
    insert(m,i,j);
    if(DISPLAY) display_m(*m);
  } 
}

/* function to swap two consecutive matches at position i and i+1 */
void swap(m_array *m,int i){
  if(i+1<m->length){
    match tmp=m->matches[i]; 
    m->matches[i]=m->matches[i+1]; 
    m->matches[i+1]=tmp; 
  }
}

/* bubble sort function */
void bubble_sort(m_array *m){
  int all_sorted=0; 
  int end=m->length-1; 
  while(!all_sorted){ 
    all_sorted=1; 
    for(int i=0;i<end;i++) { 
      if (!leq(m->matches[i],m->matches[i+1])) { 
	all_sorted=0; 
	swap(m,i);
      } 
    }end--;
    if(DISPLAY) display_m(*m);
  } 
}

// Convention: start and end are both inside
// the sub-array: they are valid indexes.
/* recursive part of the quick sort algorithm */
void quick_sort_rec(m_array *m,int start,int end){
  if(end>start){ 
    // +---+---+---+---+---+---+---+---+---+ 
    // | L | L | L | R | R | P | G | G | G | 
    // +---+---+---+---+---+---+---+---+---+ 
    // L = lower (than pivot) 
    // R = remaining (still unknown) 
    // G = greater (than pivot) 
    
    int pivot=end; 
    int i=start; 
    int lower_end=start-1; 
    int upper_start=pivot+1; 

    while(i<pivot){ 
      if (leq(m->matches[i],m->matches[pivot])){ 
	lower_end+=1; 
	++i; 
      }else{ 
	match tmp=m->matches[i]; 
	m->matches[i]=m->matches[pivot-1]; 
	m->matches[pivot-1]=m->matches[pivot]; 
	m->matches[pivot]=tmp; 
	pivot--; 
	upper_start--; 
      } 
    } 
    quick_sort_rec(m,start,lower_end); 
    quick_sort_rec(m,upper_start,end); 
  } 
}

/* quick sort function */
void quick_sort(m_array *m){
  if (m->length!=0) 
    quick_sort_rec(m,0,m->length-1);
}

