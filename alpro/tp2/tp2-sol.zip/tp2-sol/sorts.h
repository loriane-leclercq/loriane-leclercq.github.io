#ifndef SORTS_H
#define SORTS_H 1

#include "matches.h"

/* insertion sort function */
void insert_sort(m_array *m);

/* bubble sort function */
void bubble_sort(m_array *m);

/* quick sort function */
void quick_sort(m_array *m);

#endif
