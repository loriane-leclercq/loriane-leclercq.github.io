#include <stdio.h>

#include "matches.h"
#include "utilities.h"
#include "sorts.h"
#include "display.h"

int main() {;
  
  

  m_array m=read_matches("matches_data.txt");
  //m=random_matches(200);
  m_array *ptr=&m;

  init();
  display_m(*ptr);
  //insert_sort(ptr);
  bubble_sort(ptr);
  //quick_sort(ptr);
  write_matches(*ptr,"matches_sorted.txt");
  display_m(*ptr);



  finish();
  print_matches(m);
  return 0;
}
