/*************************************************************
                     TP SORTING

               Header file of display.c

    ------------------------------------------------------

 Authors: Equipe pédagogique ALGPR, translated to C by L. Leclercq
 Date: 21/04/2009, 20/09/2022
 File: display.h
 Goal: prototypes of functions to display pseudo-graphically some matches that 
we wand to sort

*************************************************************/

#ifndef DISPLAY_H_INCLUDED
#define DISPLAY_H_INCLUDED


// Colors
#define BLACK  0
#define WHITE  1
#define RED  2
#define YELLOW  3
#define BLUE  4
#define MAGENTA  5
#define GREEN  6

#define DISPLAY 1

void displayInfo(const char* s);
void displayInfoWait(const char* s);

/* function init that initializes the pseudo-graphic display */
void init();

/* function finish that exits the pseudo-graphic mode properly */
void finish();

/* function display_m that displays the matches given in the argument m_array m */
void display_m(const m_array m);

#endif 
