#ifndef MATCHES
#define MATCHES 1

#include <stdlib.h>

typedef struct match{
    int color;
    int size;
}match;

typedef struct m_array{
  match* matches;
  int length;
}m_array;


#endif
