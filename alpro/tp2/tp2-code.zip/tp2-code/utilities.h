#ifndef UTILITIES
#define UTILITIES 1

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
//#include<time.h>
#include "matches.h"

/* print matches on terminal */
void print_matches(m_array a);

/* initialize an array of matches of length l*/
m_array init_matches(int l);

/* read a m_array of matches from the file from path */
m_array read_matches(const char *path);

/* write the m_array of matches m in the file from path */
void write_matches(m_array m,const char *path);



#endif
