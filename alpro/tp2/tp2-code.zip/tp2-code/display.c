/*************************************************************
                     TP SORTING

        source file display.c

    ------------------------------------------------------

 Authors: Equipe pédagogique ALGPR, translated to C by L. Leclercq
 Date: 21/04/2009
 Modification : 10/10/2013, 20/08/2022
 File: display.c
 Goal: set of functions to pseudo-grafically display some matches that we want 
to sort. 

*************************************************************/

#include <curses.h>	// for the pseudo-grafical display
#include <time.h>       // for the mangement of the display tempo
#include <stdio.h>
#include "matches.h"
#include "display.h"

// Internal macros (Do not change)
#define gotoxy(x,y) move(y, x)
#define textcolor(color) attrset(COLOR_PAIR(color))



void displayInfo(const char* s){
  if(DISPLAY){
    textcolor(9);
    gotoxy(0,21);
    printf("\n%s\n",s);
    refresh();
  }else{
    printf("%s\n",s);
  }
}


void displayInfoWait(const char* s){
  if(DISPLAY){
    textcolor(9);
    gotoxy(0,21);
    printf("\n%s : press a key to continue\n",s);
    refresh();
    getchar();
  }else{
    printf("\n%s\n",s);
  }
}


/* function finish that exits the pseudo-graphic mode properly */
void finish(){
  if(DISPLAY){
    textcolor(9);
    gotoxy(0,21);
    printw("\nFin : appuyer sur une touche pour terminer\n");
    refresh();
    
    getchar();
    endwin();
  }
}


/* function init that initializes the pseudo-graphic display */
void init(){
  if(DISPLAY) {
    initscr();      			/* initialize the curses library */
    keypad(stdscr, TRUE);  		/* enable keyboard mapping */
    nonl();         			/* tell curses not to do NL->CR/NL on output */
    cbreak();       			/* take input chars one at a time, no wait for \n */
    noecho();       			/* don't echo input */
    nodelay(stdscr, TRUE);		/* getch() don't wait for an input */
    if (has_colors()){
      start_color();
      
      // Initialize the colors
      // Only the background is changing to display some " " of different colors
      init_pair(0, COLOR_BLACK, COLOR_BLACK);
      init_pair(1, COLOR_BLACK, COLOR_WHITE);
      init_pair(2, COLOR_BLACK, COLOR_RED);
      init_pair(3, COLOR_BLACK, COLOR_YELLOW);
      init_pair(4, COLOR_BLACK, COLOR_BLUE);
      init_pair(5, COLOR_BLACK, COLOR_MAGENTA);
      init_pair(6, COLOR_BLACK, COLOR_GREEN);
      
      // A color for the writing: white on black background 
      init_pair(9, COLOR_WHITE, COLOR_BLACK);
    }else{
      printw("The terminal does not support colors!\n");
      finish();
    }
  }
}


/* function display_m that displays the matches in m_array m given in argument */
void display_m(const m_array m){
  if(DISPLAY){
    int i,j;
    int end_wait=0;
    static unsigned int displayTime=200 ; //500;   // initial delay, in us.
    /*
      static unsigned int cp=0 ;
      gotoxy(0,22);
      printw("cp : %d\n",cp);
      cp++;
    */
    for (i = 0; i <m.length; i++){
      // Check size (between 1 and 20)
      if ( (m.matches[i].size>20) || (m.matches[i].size<1) ){
	gotoxy(1,21);
	printw("L'allumette no %u a une taille invalide : %u\n",i,m.matches[i].size);
      }
      
      // Check color (between 1 and 6)
      if ( (m.matches[i].color<WHITE) || (m.matches[i].color>GREEN) ){
	gotoxy(1,22);
	printw("L'allumette no %u a une couleur invalide : %u\n",i,m.matches[i].color);
      }else
	textcolor(m.matches[i].color);
      
      // Display matches
      for (j = 0; j < m.matches[i].size; j++){
	// Positioning
	gotoxy((i*2),20-j);
	
	// Display a space (the black background makes it display a colored square)
	
	printw(" ");
      }
      
      // Change the color for the background color
      textcolor(0);
      
      // Erase the previous match (by displaying squares of the background color)
      for(j=m.matches[i].size; j<20; j++){
	// Positioning
	gotoxy((i*2),20-j);
	
	// Display a space of the background color
	printw(" ");
      }
    }
    
    printw("\n");
    
    // Update the display
    refresh();
    
    
    // Waiting and management of events
    time_t time=clock();
    while (!end_wait){
      // Key management
      int key = getch();
      if (key==KEY_UP){
	if (displayTime > 100)
	  displayTime -= 100;
	else if (displayTime > 10)
	  displayTime--;
      }
      if (key==KEY_DOWN){
	if (displayTime < 100)
	  displayTime++;
	else if (displayTime < 5000)
	  displayTime += 100;
      }
      
      // Check if we have waited long enough
      end_wait = ( (clock()-time)*5000/CLOCKS_PER_SEC ) > displayTime;
    }
  }
}
