#include <stdio.h>

#include "matches.h"
#include "utilities.h"
//#include "sorts.h"
#include "display.h"

int main() {
  

  init();


  // display your matches here



  finish();
  return 0;
}
