/*************************************************************

          Random draw and weighted random draw

    ------------------------------------------------------

 Auteur: HILAIRE Thibault
 Date: 01/10/2003
 Révisé et porté en C par Didier LIME le 7/05/2009
 File: proba.c
 Goal: Functions allowing to make a draw (between 0 and a maximum number given 
       in argument) and a weighted draw, between 0 and 7 (the draw is not 
       equiprobable, a weighting vector is given in argument)

*************************************************************/


#include <stdlib.h>		// for rand()
#include <stdio.h>		// for fprintf()
#include <math.h>		// for floor()
#include "proba.h"		// types et declaration of functions


//function: nalea
//parameter: max: maximum value for the random draw
//goal: return a random integer between 0 and max-1 (inclusive)
int nalea(int max){
  // the rand() function return an integer between 0 and RAND_MAX-1
  return (int)floor(rand()*((float)max)/RAND_MAX);
}


//function: weighted_nalea
//parameter: weight: weighting vector
//goal: return a random number (between 0 and 7). The draw is not equiprobable because it is weighted by the weight vector
// principle: we compute a vector of partial sums of weights, we draw lots between 0 and the sum of weights-1, then we see to which index this draw refers.
int nalea_weighted( t_weight weight){
  t_weight s;
  int rand;
  int i;

  // checks on the weighting vector
  int sum;
  for(i=0;i<8;i++){
    if (weight[i]<0)
      fprintf(stderr, "Warning (nalea_weight) : a weighting cannot be negative (weight[%d]=%d)\n", i, weight[i]);
    sum = sum + weight[i];
  }
  if (sum==0)  fprintf(stderr, "Warning (nalea_weighted) : all weightings are null\n");

  // partial sum
  s[0]=0;
  for(i=1;i<8;i++)
    s[i]=s[i-1]+weight[i-1];

  // random draw
  rand=nalea(s[7]+weight[7]);

  // search
  for(i=7;i>=0;i--)
    if (s[i]<=rand){
      return i;
    }
  return 0;	// never useful
}
