#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "ant.h"
#include "world.h"
#include "proba.h"

const int tdx[8]={+1,+1,0,-1,-1,-1, 0,+1};
const int tdy[8]={0,+1,+1,+1, 0,-1,-1,-1};
const int straight[8]={12,2,1,1,0,1,1,2};
// const int straight[8]={12,2,1,1,1,1,1,2};
const int dir_anthill[8]={200,32,8,2,1,2,8,32};


t_ant init_ant(t_world m){
  t_ant f ;
  f.x=m.hx;
  f.y=m.hy;
  f.mode=0;
  f.dir=nalea(8);
  return f;
}


int direction_anthill(int x,int y,int hx,int hy){
  int dir = 0;
  int dx = hx-x;
  int dy = hy-y;
  double norm  = sqrt(dx*dx+dy*dy);
  dx=(int)round(dx/norm);
  dy=(int)round(dy/norm);
  
  for(int i=0;i<8;++i){
    if(dx==tdx[i] && dy==tdy[i])
      dir = i;
  }

  return dir;
}

void move_ant(t_ant *f){
  int d = nalea(8);
  f->x += tdx[d];
  f->y += tdy[d];
}

void move_ant2(t_ant *f,const t_world e){
  t_weight weightings;

  for(int i=0;i<8;++i){
    int dir = (i-(f->dir)+8)%8;
    weightings[i] = straight[dir];
  }
  
  for(int i=0;i<8;++i)
    if(!possible_position(f->x+tdx[i],f->y+tdy[i],e))
      weightings[i]=0;

  f->dir = nalea_weighted(weightings);

  f->x += tdx[f->dir];
  f->y += tdy[f->dir];
}

void move_ant3(t_ant *f,t_world *e){
  t_weight weightings;
  if(f->mode==0){
    for(int i=0;i<8;++i){
      int dir = (i-f->dir+8)%8;
      weightings[i] = straight[dir];
    }
  
    for(int i=0;i<8;++i){
      int nx= f->x+tdx[i];
      int ny =f->y+tdy[i];
      if( e->mat[ny][nx]>0 && !(nx==e->hx && ny==e->hy) )  // food && not on the anthill
        weightings[i]=100000;
    }

    for(int i=0;i<8;++i)
      if(!possible_position(f->x+tdx[i],f->y+tdy[i],*e))
        weightings[i]=0;

    f->dir = nalea_weighted(weightings);

    f->x += tdx[f->dir];
    f->y += tdy[f->dir];

    if(e->mat[f->y][f->x] && !(f->x==e->hx && f->y==e->hy) ){
      e->mat[f->y][f->x]--;
      f->mode=1;
    }
  }
  else{
    int dir_ah = direction_anthill(f->x,f->y,e->hx,e->hy);
    for(int i=0;i<8;++i){
      int dir = (i-dir_ah+8)%8;
      weightings[i] = dir_anthill[dir];
    }
  
    for(int i=0;i<8;++i){
      int nx= f->x+tdx[i];
      int ny =f->y+tdy[i];
      if( nx==e->hx && ny==e->hy )  // food && not on anthill
        weightings[i]=100000;
    }

    for(int i=0;i<8;++i)
      if(!possible_position(f->x+tdx[i],f->y+tdy[i],*e))
        weightings[i]=0;

    f->dir = nalea_weighted(weightings);

    f->x += tdx[f->dir];
    f->y += tdy[f->dir];

    if( f->x==e->hx && f->y==e->hy ){
      e->mat[f->y][f->x]++;
      f->mode=0;
    }
  }
}


void move_ant4(t_ant *f,t_world *e,t_world *ph){
  t_weight weightings;
  if(f->mode==0){
    for(int i=0;i<8;++i){
      int dir = (i-f->dir+8)%8;
      weightings[i] = straight[dir];
    }

    if(ph->mat[f->y][f->x]){
      int dir_ah = direction_anthill(f->x,f->y,e->hx,e->hy);
      for(int i=0;i<8;++i){
        int diff_anthill = (i - dir_ah+8)%8-4; // the difference between the direction of the ant and the direction of the anthill 
        weightings[i] += ph->mat[f->y+tdy[i]][f->x+tdx[i]]*(4-abs(diff_anthill));
      }
    }

  
    for(int i=0;i<8;++i){
      int nx= f->x+tdx[i];
      int ny =f->y+tdy[i];
      if( e->mat[ny][nx]>0 && !(nx==e->hx && ny==e->hy) )  // food && not on anthill
        weightings[i]=100000;
    }

    for(int i=0;i<8;++i)
      if(!possible_position(f->x+tdx[i],f->y+tdy[i],*e))
        weightings[i]=0;

    f->dir = nalea_weighted(weightings);
    f->x += tdx[f->dir];
    f->y += tdy[f->dir];

    if(e->mat[f->y][f->x] && !(f->x==e->hx && f->y==e->hy) ){
      e->mat[f->y][f->x]--;
      f->mode=1;
    }
  }
  else{
    int dir_ah = direction_anthill(f->x,f->y,e->hx,e->hy);
    for(int i=0;i<8;++i){
      int dir = (i-dir_ah+8)%8;
      weightings[i] = dir_anthill[dir];
    }
  
    for(int i=0;i<8;++i){
      int nx= f->x+tdx[i];
      int ny =f->y+tdy[i];
      if( nx==e->hx && ny==e->hy )  // food && not on anthill
        weightings[i]=100000;
    }

    for(int i=0;i<8;++i)
      if(!possible_position(f->x+tdx[i],f->y+tdy[i],*e))
        weightings[i]=0;

    f->dir = nalea_weighted(weightings);

    f->x += tdx[f->dir];
    f->y += tdy[f->dir];
    ph->mat[f->y][f->x] += 10;
    for(int i=0;i<8;++i)
      ph->mat[f->y+tdy[i]][f->x+tdx[i]] += 5;

    if(ph->mat[f->y][f->x]>PHEROMONES_MAX)
      ph->mat[f->y][f->x] = PHEROMONES_MAX;
    for(int i=0;i<8;++i){
      if(ph->mat[f->y+tdy[i]][f->x+tdx[i]]>PHEROMONES_MAX)
        ph->mat[f->y+tdy[i]][f->x+tdx[i]]=PHEROMONES_MAX;
    }

    if( f->x==e->hx && f->y==e->hy ){
      e->mat[f->y][f->x]++;
      f->mode=0;
      f->dir=(f->dir+4)%8; // opposite direction
    }
  }
}
