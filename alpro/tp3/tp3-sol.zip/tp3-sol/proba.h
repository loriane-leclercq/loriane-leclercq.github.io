/*************************************************************

                  Header file of proba.c

    ------------------------------------------------------

 Authors : équipe pédagogique ALGPR
 Date: 01/10/2005
 File: proba.h
 Goal: prototypes of the functions allowing to perform a random drow(between 0 
       and a maximum number given in parameter) and a weighted draw, between 0 
       and 7 (the draw is not equiprobable, a weighted vector is given in 
       parameter) 

*************************************************************/

#ifndef PROBA_H
#define PROBA_H


// definition of a type "t_weight" which is a vector of 8 integers
typedef int t_weight[8];


//function: nalea
//parameter: max: maximum value for the random draw
//goal: return a random integer between 0 and max-1 (inclusive)
int nalea(int max);


//function: weighted_nalea
//parameter: weight: weighting vector
//goal: return a random number (between 0 and 7). The draw is not equiprobable because it is weighted by the weight vector
int nalea_weighted(t_weight weight);

#endif
