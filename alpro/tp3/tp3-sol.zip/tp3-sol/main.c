#include <stdio.h>

#include "constants.h"
#include "proba.h"
#include "display.h"
#include "world.h"
#include "ant.h"


int main(){
  t_world m = read_environment("world4.dat");

  int t_food = total_food(m);
  t_world ph = init_pheromones(m); 

  int nb_ants = 200 ;
  t_ant ants[nb_ants];
  for(int i=0;i<nb_ants;++i){ // i< size of ants
    ants[i]=init_ant(m);
  }
  printf("mode h= %d l= %d Food= %d nb ants= %d\n",m.h, m.w, t_food, nb_ants); 

  int ret;
  ret = init_display(m.w,m.h);

  int loop = 0;
  while(ret==1 && m.mat[m.hy][m.hx]<t_food){
    for(int i=0;i<nb_ants;++i){ //size of ants
      //move_ant(&ants[i]);
      //move_ant2(&ants[i],m);
      //move_ant3(&ants[i],&m);
      move_ant4(&ants[i],&m,&ph);

      update_ant(ants[i].x,ants[i].y,ants[i].mode);
    }
    
    if(loop%10==0)
      evaporation_pheromones(&ph);

    update_environment(m);
    update_pheromones(ph.mat);
    ret=display_();

    if(loop%100==0)
      printf("iteration= %d harvest= %d / %d\n",loop,m.mat[m.hy][m.hx],t_food);

    loop++;
  }
  printf("Finished harvest in %d rounds\n", loop);
}
