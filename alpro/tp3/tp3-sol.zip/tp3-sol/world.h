#ifndef WORLD_H
#define WORLD_H

#include <string.h>

#include "constants.h"

t_world read_environment(const char* path) ;
int possible_position(int x,int y,const t_world env) ; //return a boolean
int total_food(const t_world env);

t_world init_pheromones(const t_world env) ;
void evaporation_pheromones(t_world *env) ;

#endif
