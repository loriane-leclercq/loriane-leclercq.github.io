#ifndef ANT_H
#define ANT_H

#include "constants.h"

typedef struct t_ant{
  int x,y ;
  int mode ;
  int dir ;
}t_ant;

t_ant init_ant(t_world m);

int direction_anthill(int x,int y,int hx,int hy);

void move_ant(t_ant *f);
void move_ant2(t_ant *f,const t_world e);
void move_ant3(t_ant *f,t_world *e);
void move_ant4(t_ant *f,t_world *e,t_world *p);

#endif
