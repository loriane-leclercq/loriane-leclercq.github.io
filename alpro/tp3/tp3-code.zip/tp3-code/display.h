/*************************************************************

               Header file display.h

    ------------------------------------------------------
 Authors : équipe pédagogique ALGPR
 Date : 01/10/2005
 Modified : 10/04/2013, 04/11/2013 (Vincent Tourre), 
            20/04/2022 (Loriane Leclercq)
 File: display.h
 Goal: prototypes of functions allowing to manage the display of ants, the 
       world in which they evlove (food and obstacles) and pheromones.

*************************************************************/

#ifndef DISPLAY_H
#define DISPLAY_H

#include "constants.h"



//function: init_display
//parameters: w: width of the world to display
//            h: height of the world to display
//goal: prepare the world display
//      this function return 0 if the initialization did not worked (and 1 otherwise) 
//      this function must be used ONLY ONCE, and before all others
int init_display(int w, int h);


//function: update_ant
//parameters: x: position in x of the ant to display
//            y: position in y of the ant to display
//            mode: indicates which mode the ant is in
//                  0 : the ant is in "I found food, I'm going back to the ant farm" mode 
//                  1 : the ant is in "I'm looking for food" mode 
//goal: update the ant in the world
void update_ant( int x, int y, int mode);


//function: update_environment
//parameter: environment : t_world containing the environment (obstacles and food)
//goal: display the current environment (obstacles in blue and food in green: a green dot in the middle, and a rectangle whose green intensity indicates the quantity of food present) 
void update_environment(const t_world environment);


//function: update_pheromones
//parameter: pheromones: matrix representing the quantity of pheromones
//goal: update the quantity of pheromones of the world
void update_pheromones(const t_matrix pheromones);


//function: display_
//goal: allows to pause at the end of the display necessary to manage graphical //      events (moving the window, pressing a key on the keyboard, ect...)
//      return 0 if the user has pressed the ESC key (and 1 otherwise)
int display_();

#endif
