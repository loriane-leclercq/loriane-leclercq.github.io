#ifndef WORLD_H
#define WORLD_H

#include <string.h>

#include "constants.h"


t_world read_environment(const char* path) ;

#endif
