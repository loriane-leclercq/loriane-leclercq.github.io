/*************************************************************

           Functions to manage the display of  
             ants and the surrounding world
                (display made under X11)

    ------------------------------------------------------

 Authors: HILAIRE Thibault, BRIDAY Mikaël
 Date: 01/10/2003
 Révisé et porté en C par Didier LIME le 7/05/2009
 modified: 10/04/2013, 04/11/2013 (Vincent Tourre), 
           20/04/2022 (Loriane Leclercq)
 File: display.c
 Goal: functions allowing to manage the display of ants, the world in which 
       they evlove (food and obstacles) and pheromones.

*************************************************************/

#include <X11/Xlib.h>		// for XLib
#include <X11/keysym.h>		// for the XLib keys

#include <stdio.h>   // for error display
#include <time.h>    // to initialize the random generator with the current time
#include <stdlib.h>  // for srand and malloc
#include <unistd.h>

#include "constants.h" 	 // define FOOD_MAX



// constants (for le graphic display)
#define CASE 7
#define ANT 2
#define COLOR_INDEX_PHERO_MAX 100


// type "t_pos" to store an ant (its position and mode)
typedef struct t_pos{
  int x;
  int y;
  int search;
}t_pos;

// Linked list of t_pos
typedef struct t_lpos t_lpos;
struct t_lpos{
  t_pos pos;
  t_lpos * next;
};


#include "display.h"	// declaration of functions

// X11 variables
Display* display;
int screen;
GC gc;
Window w;
Colormap cmap;

// Pixmap
Pixmap pix;
Pixmap fond;

// colors
unsigned int ColAnts[2];
unsigned int ColObstacle;
unsigned int ColFood;
unsigned int ColTabFood[FOOD_MAX + 1];
unsigned int ColAntFarm;
unsigned int ColPheromones[COLOR_INDEX_PHERO_MAX+1];
unsigned int ColBackground;


// common variables
int init=0;		// allows to know if you have launched init_display

t_lpos* ants = NULL;    // list of ant positions
t_world env;		// copy of the environment

//t_pos anthill;	// position of the anthill


//function: AllocateColor
//arguments: red,green,blue : quantity (16bits) of red,green et blue that composes the color
//goal: allocation of a color in the ColorMap
//principle: function XAllocColor - return an unsigned integer identifying the color in the ColorMap
unsigned int AllocateColor( int red, int green, int blue){
  XColor col;
  col.green = green;
  col.red = red;
  col.blue = blue;
  XAllocColor( display, cmap, &col);
  return col.pixel;
}


//function: phero2index
//arguments: phero : value of pheromones
//           x,y : position of the pheromone
//goal: allows the conversion between pheromone and color to be displayed in
//    order to pass from a pheromone index (between -PHEROMONES_MAX and
//    PHEROMONES_MAX) to a color index (between 0 and COLOR_INDEX_PHERO_MAX-1).
//    also allows to check the level of pheromones
// principle: index<-phero*COLOR_INDEX_PHERO_MAX/(PHEROMONES_MAX+1)
int phero2index( int phero, int x, int y){
  if ( phero<0 ){
    fprintf(stderr, "Warning (update_pheromones) : the pheromone index cannot be negative (x=%d y=%d phero=%d)\n",x,y,phero);
    phero=0;
  }
  if (phero>PHEROMONES_MAX){
    fprintf(stderr, "Warning (update_pheromones) : the pheromone index cannot be more than %d (x=%d y=%d phero=%d)\n",PHEROMONES_MAX,x,y,phero); 
    phero=PHEROMONES_MAX;
  }
  return phero*COLOR_INDEX_PHERO_MAX/(PHEROMONES_MAX+1);
}


//function: init_affichage
//arguments: w : width of the world to display
//           h : height of the world to display
//goal: prepare the world display
//      this function return 0 if the initialization did not worked (and 1 otherwise) 
//      this function must be used ONLY ONCE, and before all others
//principle: creation of the X11 window, initialization of colors, pixmap, etc...
int init_display(int w1, int h){
  int i,j;
  // Check
  if ( (w1>WORLD_SIZE_MAX) || (h>WORLD_SIZE_MAX) ){
    fprintf(stderr, "Error (init_display) : the height and width of the 'world' cannot exceed %d",WORLD_SIZE_MAX);
    return 0;
  }
  if ( (w1<5) || (h<5) ){
    fprintf(stderr, "Error (init_display) : the height and width of the 'world' cannot be less than 5\n");
    return 0;
  }

  // Initialisation X11
  if ( (display=XOpenDisplay(NULL)) == NULL ){
    fprintf(stderr, "Error (init_display) : connection with X impossible : is X launched ??\n");
      return 0;
    }

  // creates the window
  screen = DefaultScreen(display);
  gc = DefaultGC (display, screen);
  cmap = DefaultColormap( display, screen);
  w = XCreateSimpleWindow( display, RootWindow(display,screen), 0,0, w1*CASE+5,h*CASE+5,2, BlackPixel(display,screen), WhitePixel(display,screen));
  XStoreName( display, w, "AntZ");

  // creates the color table
  ColObstacle = AllocateColor( 5000,5000,65535);	// blue
  ColFood = AllocateColor( 5000,65535,5000);		// vert
  for(i=0;i<=FOOD_MAX;i++){
    int j = 30000*i/FOOD_MAX;
    ColTabFood[i] = AllocateColor( 65535-2*j,65535-j,65535-2*j);// white->yellow
  }
  ColAntFarm = AllocateColor( 65535,5000,65535);	// purple
  ColAnts[1] = AllocateColor( 65535,5000,5000);		// red
  ColAnts[0] = AllocateColor( 8000,8000,65535);		// light blue
  ColBackground = AllocateColor( 50000,50000,50000);   	// grey
  for(i=0;i<COLOR_INDEX_PHERO_MAX+1;i++){
    int j = (30000/COLOR_INDEX_PHERO_MAX)*i;
    ColPheromones[i] = AllocateColor( 65535-2*j,65535-j,65535-j);			// white->grey/green
  }

  // creates the pixmap in which we will draw everything
  int prof = XDefaultDepth (display, screen);
  pix = XCreatePixmap (display, RootWindow(display,screen), w1*CASE+1,h*CASE+1, prof);

  // creates the background pixmap (in which we will add obstacles)
  fond = XCreatePixmap (display, RootWindow(display,screen), w1*CASE+1,h*CASE+1, prof);
  XSetForeground( display, gc, WhitePixel(display,screen) );
  XFillRectangle( display,fond,gc, 0,0, w1*CASE+1,h*CASE+1);
  XSetForeground( display, gc, ColBackground);
  for(i=0;i<=h;i++)	XDrawLine( display,fond,gc, 0,i*CASE,w1*CASE,i*CASE);
  for(j=0;j<=w1;j++)	XDrawLine( display,fond,gc, j*CASE,0,j*CASE,h*CASE);
  XCopyArea( display, fond, pix, gc, 0,0, w1*CASE+1,h*CASE+1, 0,0);
  
  // initialization of obstacles and reserved spaces...
  env.w=w1;
  env.h=h;
  env.hx=env.hy=0;
  for(i=0;i<=h;i++)
    for(j=0;j<=w1;j++)
      env.mat[i][j]=EMPTY;

  // select the events to be managed (display renewal and key management)
  XSelectInput (display, w, ExposureMask | KeyPressMask);

  // displays the window
  XMapWindow(display, w);

  //we take this opportunity to initialize the random number generator, with the current date
  srand(time(0));

  // update of init (which indicates if you have passed in init_display)
  init=1;

  return 1;
}


//function: update_ant
//parameters: x: position in x of the ant to display
//            y: position in y of the ant to display
//            mode: indicates which mode the ant is in
//                  0 : the ant is in "I found food, I'm going back to the ant farm" mode 
//                  1 : the ant is in "I'm looking for food" mode 
//goal: update the ant in the world
//principle: we store the parameters of the ant in a list, and we display it in display_
//(we can display it only after having displayed the food and the pheromone, and we take the opportunity to display them all at the same time)
void update_ant( int x, int y, int search){
  // Checks
  if (!init) fprintf(stderr, "Warning (update_ant) : init_display has not yet been executed\n");
  if ( (x<0) || (x>=env.w) || (y<0) || (y>=env.h) )
    fprintf(stderr, "Warning (update_ant) : Incorrect ant coordinates (x=%d  y=%d)\n",x,y);
  if (env.mat[y][x]==OBSTACLE)
    fprintf(stderr, "Warning (update_ant) : an ant is on an obstacle (x=%d  y=%d)\n",x,y);

  // Creates and adds the ant
  t_lpos* nf = malloc(sizeof(t_lpos));
  nf->pos.x = x;
  nf->pos.y = y;
  nf->pos.search = search;
  nf->next = ants;
  ants = nf;
}



//function: update_environment
//parameter: environment : t_world containing the environment (obstacles and food)
//goal: display the current environment (obstacles in blue and food in green: a green dot in the middle, and a rectangle whose green intensity indicates the quantity of food present) 
//principle: copy the environment in the global variable environment (to check
//           that the ants don't walk on the obstacles) and display of the
//           rectangles (different colors)
void update_environment(const t_world environ){
  int i,j;
  // checks
  if (!init)
    fprintf(stderr, "Warning (update_environment) : init_display has not yet been executed\n");

  if ( (env.h!=environ.h) || (env.w!=environ.w) ){
    fprintf(stderr, "Warning (update_environment) : the size of the environment passed as an argument to display_environment is not the same size as that given to the function init_display\n");
    fprintf(stderr, "\t\t size given to init_display : (%d, %d)\n", env.w, env.h);
    fprintf(stderr, "\t\t size of this environment  : (%d, %d)\n", environ.w, environ.h);
  }
	
  // copy of the matrix + display
  for(i=0;i<env.h;i++)
    for(j=0;j<env.w;j++){
      if (environ.mat[i][j]==OBSTACLE){
	// copy the obstacles on pix
	XSetForeground( display, gc, ColObstacle);
	XFillRectangle( display,pix,gc, j*CASE+1,i*CASE+1, CASE-1, CASE-1);
      }
      else if ( (environ.mat[i][j]<=FOOD_MAX) && (environ.mat[i][j]>EMPTY) ){
	// copy the food on pix
	XSetForeground( display, gc, ColTabFood[ environ.mat[i][j] ]);
	XFillRectangle( display,pix,gc, j*CASE+1,i*CASE+1, CASE-1, CASE-1);
	XSetForeground( display,gc, ColFood);
	XFillRectangle( display,pix,gc, j*CASE+3,i*CASE+3, ANT, ANT);
      }
      else{
	if ( (i!=environ.hy) && (j!=environ.hx) && (environ.mat[i][j]!=EMPTY) )
	  fprintf(stderr, "Warning (update_environment) : the environment tab contains other values than OBSTACLE, EMPTY or a food amount of food greater than %d\n", FOOD_MAX);
      }
      env.mat[i][j] = environ.mat[i][j];
    }

  // copy the anthill on pix
  XSetForeground( display, gc, ColAntFarm);
  XFillRectangle( display,pix,gc, environ.hx*CASE+1,environ.hy*CASE+1, CASE-1, CASE-1);
  env.hx=environ.hx;
  env.hy=environ.hy;

}


//function: update_pheromones
//parameter: pheromones: matrix representing the quantity of pheromones
//goal: update the quantity of pheromones of the world
//principle: display (color according to the quantity of pheromones) a
//     rectangle on the empty cells (no pheromones are displayed elsewhere,
//     neither on the obstacles, the food or the ant farm)
void update_pheromones(const t_matrix phero){
  int i,j;
  // checks
  if (!init)
    fprintf(stderr, "Warning (update_pheromones) : init_display has not yet been executed\n");

  // browsing the table
  for(i=0;i<env.h;i++)
    for (j=0;j<env.w;j++){
      if ( (env.mat[i][j]==EMPTY) && ((i!=env.hy) || (j!=env.hx)) ){
	XSetForeground( display, gc, ColPheromones[ phero2index(phero[i][j],j,i) ]);
	XFillRectangle( display,pix,gc, j*CASE+1,i*CASE+1, CASE-1, CASE-1);
      }
    }
}


//function: display_
//goal: allows to pause at the end of the display necessary to manage graphical //      events (moving the window, pressing a key on the keyboard, ect...)
//      return 0 if the user has pressed the ESC key (and 1 otherwise)
//principle: we display the ants on the pix, then we display the pix on the
//    screen (the ants, the obstacles, the food are displayed all together, and
//    in one time). A waiting loop (delay fixed by argument) allows to manage
//    the events/signals which can intervene : window hidden or redisplayed
//    window, pressed key, etc...
int display_(){
  static int nb_iter = 1;
  static unsigned int tempoDisplay = 10; //in us.
  
  // checks
  if (!init)
    fprintf(stderr, "Warning (display_) : init_display has not yet been executed\n");

  // displays the ants by browsing the list of ants 
  t_lpos* it;
  t_lpos* its;
  it = ants;
  while (it != NULL){
    // Display the ant
    XSetForeground( display, gc, ColAnts[it->pos.search]);
    XFillRectangle( display,pix,gc, it->pos.x*CASE+3,it->pos.y*CASE+3, ANT,ANT);
        
    // and removes it from the list 
    its = it;
    it = it->next;
    free(its);
  }
  ants = NULL;

  // displays everything on the screen 
  XCopyArea( display, pix, w, gc, 0,0, env.w*CASE+1,env.h*CASE+1, 2,2);

  // copy the background (grid) on pix for the next round
  XCopyArea( display, fond, pix, gc, 0,0, env.w*CASE+1,env.h*CASE+1, 0,0);
	
  // waiting and event management 
  time_t time=clock();
  XEvent e;
  while (XPending(display)){	   // is there an event waiting for us
    XNextEvent(display,&e);
    switch (e.type){
    case Expose :			// redisplay requested
      XCopyArea( display, pix, w, gc, 0,0, env.w*CASE+1,env.h*CASE+1, 2,2);
      break;
    case KeyPress:			// pressed key
      if (XLookupKeysym(&e.xkey, 0) == XK_KP_Add){	// ('+') faster
	tempoDisplay *=1.1; //+10%
      }
      else if (XLookupKeysym(&e.xkey, 0) == XK_KP_Subtract){	// ('-') slower
	tempoDisplay *=.9; //-10%
      }
      else if (XLookupKeysym(&e.xkey, 0) == XK_Escape){
	XCloseDisplay( display);
	
	// tests if the anthill is correctly placed 
	if ( (env.hx<0) || (env.hx>env.w) || (env.hy<0) || (env.hy>env.h) ){
	  fprintf(stderr, "Warning (display_) : the ant farm is placed on (%d, %d)\n", env.hx, env.hy);
	}
	else{
	  // displays the conclusions: food per anthill 
	  printf("Simulation in %d iterations\n", nb_iter); 
	  printf("Food brought to the ant farm = %d\n", env.mat[env.hy][env.hx]);
	}
	return 0;
      }
      break;
    }
  }
  // check if we waited long enough
  // (absolutely horrible way to do it, I'm ashamed; but to do "clean" would take me too much time)
  const int waitingUS =  ((clock()-time)*1000000/CLOCKS_PER_SEC);
  struct timespec ts;
  ts.tv_sec=0;
  ts.tv_nsec=tempoDisplay-waitingUS;
  if(waitingUS < tempoDisplay) nanosleep(&ts,&ts);
  ts.tv_sec=0;
  ts.tv_nsec=10e+6;
  nanosleep(&ts,&ts);
  
  nb_iter++;	// counts the number of iterations
  return 1;
}
