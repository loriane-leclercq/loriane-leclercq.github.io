#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "world.h"

t_world read_environment(const char* path){
  t_world map;
  FILE *world_in;
  world_in=fopen(path,"r");
  if(world_in==NULL){
    fprintf(stderr,"\n ERROR : Impossible to read the file %s\n", path);
    return map;
  }
  int max_length_line=1024;
  char *line=(char*)malloc(max_length_line);
  char *buff;
  
  /* get size of world */
  line=fgets(line,max_length_line,world_in);
  if(!feof(world_in)){
    buff=strtok(line," ");
    
    if(buff!=NULL){
      map.w=atoi(buff);
      buff=strtok(NULL," ");
      if(buff!=NULL){
	map.h=atoi(buff);
	buff=strtok(NULL," ");
	if (buff!=NULL){
	  fprintf(stderr,"\n ERROR : Wrong format in the file %s\n", path);
	  return map;
	}  
      }	  
    }    
  }
  
  /* get position of anthill */
  line=fgets(line,max_length_line,world_in);
  if(!feof(world_in)){
    buff=strtok(line," ");
    
    if(buff!=NULL){
      
      map.hx=atoi(buff);
      buff=strtok(NULL," ");
      if(buff!=NULL){
	
	map.hy=atoi(buff);
	buff=strtok(NULL," ");
	if (buff!=NULL){
	  fprintf(stderr,"\n ERROR : Wrong format in the file %s\n", path);
	  return map;
	}  
      }	  
    }
  }
  
  /* get values of map */
  line=fgets(line,max_length_line,world_in);
  int i=0;
  while(!feof(world_in)){
    buff=strtok(line," ");
    for(int j=0;j<map.w;j++){
      if(buff==NULL){
	fprintf(stderr,"\n ERROR : Wrong size w %d too large in the file %s\n",j, path); 
	return map;
      }
      map.mat[i][j]=atoi(buff);
      
      buff=strtok(NULL," ");
    }
    line=fgets(line,max_length_line,world_in);
    i++;
  }
  if (i!=map.h) 
    fprintf(stderr,"\n ERROR : Wrong size h in the file %s\n", path); \
  fclose(world_in);
  return map;
}
