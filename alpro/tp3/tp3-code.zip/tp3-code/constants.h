/*************************************************************

              Definition of constants related to ants 

    ------------------------------------------------------

 Authors : équipe pédagogique ALGPR
 Modified : 10/04/2013, 04/11/2013 (Vincent Tourre), 
    20/04/2022 (Loriane Leclercq)
 File: constants.h
 Goal: definition of constants related to ants 

*************************************************************/


#ifndef CONSTANTS_H
#define CONSTANTS_H

// definition of size constants
#define WORLD_SIZE_MAX 250
#define PHEROMONES_MAX 100

// definition of environment constants
#define OBSTACLE -1
#define EMPTY 0
#define FOOD_MAX 50



// definition of a type of integer matrix of dimension WORLD_SIZE_MAX * WORLD_SIZE_MAX 
typedef int t_matrix[WORLD_SIZE_MAX][WORLD_SIZE_MAX];


// definition of a type "t_world" which is a structure characterizing the world
// and allowing to store the environment. It is composed of:
// 	- a matrix of type t_matrix
// 	- a width
// 	- a height
//      - a position for the anthill
// allows to store the environment
typedef struct t_world{
	t_matrix mat;		// matrix
	int w;			// width
	int h;			// height
	int hx,hy;		// position of the anthill
}t_world;

#endif
