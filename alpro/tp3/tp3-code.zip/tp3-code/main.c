#include <stdio.h>

#include "constants.h"
#include "proba.h"
#include "display.h"
#include "world.h"


int main(){
  t_world m = read_environment("world1.dat");

  int ret;
  ret = init_display(m.w,m.h);
  while(ret){ 
    update_environment(m);
    ret=display_();
  }
  return ret;
}
