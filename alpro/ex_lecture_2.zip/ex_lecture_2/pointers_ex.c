#include <stdio.h>



int main(){


  /* array games */

  int arr[]={10,11,12,13,14,15}; // try it with an array of shorts, longs,...
  
  for(int i=0;i<6;i++){
    printf("in memory address %p, there is %d\n",arr+i,arr[i]);
  } // because arr+i is equivalent to &arr[i] (or *(arr+i) is equivalent to arr[i]) 


  for(int i=0;i<6;i++){
    printf("arr[%d] is %d and %d[arr] is %d\n",i,arr[i],i,i[arr]);
  } // because arr[i] is computed as *(arr+i)=*(i+arr) that corresponds to i[arr]


  
  

  return 0;
}
