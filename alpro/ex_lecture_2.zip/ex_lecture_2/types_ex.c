#include <stdio.h>
#include <string.h> // for strcpy, strcmp,...
#include <stdlib.h> // for malloc, free



int main(){

  int n=72;
  int *p=&n;

  printf("n is the integer %d\n",n);
  printf("p is the pointer to the integer n %p and has content %d\n",p,*p);

  printf("write an integer ");
  scanf("%d",&n);
  printf("your integer is %d\n",n);

  printf("Now write an integer in hexadecimal ");
  scanf("%i",p);
  printf("your integer is %d in decimal\n",n);
  printf("your integer is %o in octal, %x in hexadecimal with lowercase, %X with uppercase\n",n,n,n);


  float pi=3.14159265;
  //float pi2=3.14159;
  printf("pi is approximately %f\n",pi);

  char c='a';
  printf("write a single character ");
  scanf(" %c",&c); // if you dont leave a blank before %c, the scanf will take the previous new line as character
  printf("your character is %c\n",c);


  /* strings */

  char str0[]={'s','t','r','i','n','g','0','\0'};
  char str1[8]={'s','t','r','i','n','g','1','\0'}; // try with a smaller and bigger size 
  char str2[]="string2";

  printf("This is %s, %s and %s\n",str0,str1,str2);


  /* struct */

  struct person{
   char name[20];
   int age;
   char eye_color[20];
  }p1;

  strcpy(p1.name,"Jane");
  p1.age=25;
  strcpy(p1.eye_color,"brown");

  struct person *p2=malloc(sizeof(struct person)); // when there is a malloc, don't forget to free !


  
  strcpy(p2->name,"John");
  p2->age=10;
  strcpy(p2->eye_color,"blue");


  printf("There are 2 people: %s and %s\n",p1.name,p2->name);

  
  free(p2);



  /* arrays */

  int array1[4]={3,8,5,0};
  int array2[]={3,8,5,0};
  int array3[4];
  array3[0]=3;
  array3[1]=8;
  array3[2]=5;
  array3[3]=0;


  for(int i=0;i<4;i++){
    printf("in memory address %p, there is %d\n",array1+i,array1[i]);
  }


  /* new types */


  typedef struct person2{
    char name[20];
    int age;
    char eye_color[20];
  } person2;

  person2 pe={.name="Ash",.age=20,.eye_color="green"};
  printf("A person of new type called %s\n",pe.name);
  

}
