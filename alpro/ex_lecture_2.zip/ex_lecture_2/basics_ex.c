#include <stdio.h>

 #define CONST_NBR 20

int main(){


  /* constants */
  
  int number;
  const int const_int=1;
  number=2;
  printf("const_int is %d\n",const_int);
  printf("number is %d\n",number);
  printf("CONST_NBR = %d\n",CONST_NBR);
  number=3;
  // const_int=4; // this will rase a compile error
  // printf("const_int is now %d\n",const_int);
  printf("number is now %d\n",number);


  /* basic operators  */
  printf("\n");

  int number2=number+3;
  printf("number2 is %d\n",number2);
  int test=(number2 >= number);
  printf("(number2 >= number) is %d\n",test);
  test=(number2 < number);
  printf("(number2 < number) is %d\n",test);
  test=(number2 >= number) && (number2 < number);
  printf("(number2 >= number) && (number2 < number) is %d\n",test);
  test=(number2 >= number) || (number2 < number);
  printf("(number2 >= number) || (number2 < number) is %d\n",test);


  /* switch */
  printf("\n");
  
  int i=51;
  switch (i%7){
  case 0 :
    printf("%d is a multiple of 7\n",i);
    break;
  case 1 :
    printf("%d is equal to 1 modulo 7\n",i);
    break;
  case 2 :
    printf("%d is equal to 2 modulo 7\n",i);
    break;
  default :
    printf("%d is not strictly less than 3 modulo 7\n",i);
  }


  i=10;
  switch (i%2){
  case 1 :
    printf("%d is an odd number",i);
  case 0 :
    printf("%d is an even number",i);
  default :
    printf("\n");
  }
      

  /* if */
  printf("\n");

  int j=51;
  int k=43;
  if(j<k){
    printf("j is strictly less than k\n");
  }else{
    if(j==k)
      printf("j is equal to k\n");
    else if(j-100>k)
      printf("j is really greater than k\n");
    else
      printf("j is a little greater than k\n");
  }


  /* while */
  printf("\n");
  
  int n=0;
  // this is an infinite loop, you should stop it by killing your program (ctrl+c in a terminal)
  /*while(1){
    printf("%d\n",n);
    n++;
  } */

  printf("With while loop:\n");
  n=10;
  while(n>0){
    printf("Only %d left !\n",n);
    n--;
  }
  printf("BOOM\n\n");


  printf("And with for loop:\n");
  for(int m=10;m>0;m--){
    printf("Only %d left !\n",m);
  }
  printf("BOOM\n\n");


  /* reand write with printf scanf */

  printf("\n");
  int integer=13;
  float real=3.14159;
  printf("This print an integer %d and a real %f\n", integer,real);
  printf("This wait for you to write an integer and then a float: ");
  scanf("%d%f",&integer,&real);
  printf("Your numbers are %d and %f\n",integer,real);

  

  
  
}
