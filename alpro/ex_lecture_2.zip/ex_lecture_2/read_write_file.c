#include <stdio.h>
#include <stdlib.h> // for exit function


int main(){


  /* read file */


  FILE *input;
  char* path="test_read.txt";
  input=fopen("test_read.txt","r");
  if(input==NULL){
    fprintf(stderr,"\n ERROR : Impossible to read the file %s\n", path);
    exit(1);
  }
  int max_length_line=1024;
  char *line=(char*)malloc(max_length_line);
  char *buff;
  
  /* get content line by line */
  line=fgets(line,max_length_line,input);
  while(!feof(input)){
    //buff=strtok(line,separator); // usualy " " or ";"
    printf("%s",line);
    
    /* data initial treatment here */
    
    line=fgets(line,max_length_line,input);
  }
  fclose(input);
  
  
  /* write file */
  
  FILE *output;
  path="test_write.txt";
  output=fopen("test_write.txt","w");
  if(output==NULL){
    fprintf(stderr,"\n ERROR : Impossible to open the file %s\n", path);
    exit(1);
  }

  char content[40]="Those are 2 lines \nto write in a file\n";
  /* write content at ones */
  fprintf(output,"%s",content); // with content a string
  
  fclose(output);
  

   output=fopen("test_write.txt","a"); 
   if(output==NULL){ 
     fprintf(stderr,"\n ERROR : Impossible to open the file %s\n", path); 
    exit(1); 
   } 

   char content2[40]="and 2 other lines\n added after\n"; 
   /* write content at ones */ 
   fprintf(output,"%s",content2); // with content a string 
  
   fclose(output); 
    
}
