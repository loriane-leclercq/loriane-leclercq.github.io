#include<stdio.h>

int main(){

  int x;
  int a=x;
  int b=x;
  int c=a+b;
  c++;
  c=3;
  printf("%d\n",c);
  return 0;
}
