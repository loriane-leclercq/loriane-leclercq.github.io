

#ifndef HELLO_FCT_H
#define HELLO_FCT_H

void printHello();


#endif
