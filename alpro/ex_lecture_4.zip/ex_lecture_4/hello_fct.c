#include<stdio.h>
#include "hello_fct.h"

void printHello(){
  printf("Hello world !\n");
}
