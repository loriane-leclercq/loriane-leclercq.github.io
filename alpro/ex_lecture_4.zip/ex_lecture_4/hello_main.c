#include<stdio.h>
#include "hello_fct.h"

int main(){

  printHello();

  return 0;

}
    
